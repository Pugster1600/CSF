Sample README.txt

Eventually your report about how you implemented thread synchronization
in the server should go here
