Sample README.txt

MS1
Johnny worked on sender and connection
Matthew worked on reciever and connection

Eventually your report about how you implemented thread synchronization
in the server should go here
