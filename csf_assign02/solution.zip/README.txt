Johnny Shi and Matthew Schricker

MS1: Johnny worked on imgproc_fade and imgproc_kaleidoscope and the helper functions used by them.
MS1: Matthew worked on imgproc_grayscale, imgproc_rgb and the helper functions used by them.

MS2: Johnny worked on imgproc_grayscale and the get_color methods (like get_r)
MS2: Matthew worked on imgproc_rgb and combineData