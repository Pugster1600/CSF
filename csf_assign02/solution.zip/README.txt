TODO: names of team members

TODO: contributions of each team member
