Johnny Shi and Matthew Schricker

Johnny worked on imgproc_fade and imgproc_kaleidoscope and the helper functions used by them.
Matthew worked on imgproc_grayscale, imgproc_rgb and the helper functions used by them.