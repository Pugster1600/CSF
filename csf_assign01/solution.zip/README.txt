Johnny Shi and Matthew Schricker


ms1: Johnny worked on uint256_is_bit_set and uint256_get_bits
ms1: Matthew worked on uint256_create_from_u32 and uint256_create

ms2: Johnny worked on uint256_create_from_hex, uint256_format_as_hex, uint256_sub and uint256_negate
ms2: Matthew worked on uint256_mul, uint256_lshift and uint256_add

